package ui;
import java.util.Scanner;

import model.*;

public class Main {

	private static MobilitySecretary secretary=new MobilitySecretary();
	private static Scanner reader = new Scanner(System.in);
	public static void main(String[] args) {
		
		boolean execute = true;
		int decission=0;
		
		while(execute) {
			System.out.println("(1) Importar datos"
					+ "\n (2) Agregar valla publicitaria"
					+ "\n (3) Mostrar vallas publicitarias"
					+ "\n (4) Reporte de peligrosidad");
			
			decission = reader.nextInt();
			switch(decission) {
				case 1: loadData();
				break;
				case 2: addBillboard();
				break;
				case 3: showBillboard();
				break;
				case 4: dangerousnessReport();
				break;
			}
		}

	}
	public static void loadData() {
		secretary.loadData();
	}
	public static void addBillboard() {
		System.out.println("Ingresa el ancho");
		int w = reader.nextInt();
		System.out.println("Ingresa la altura");
		int h = reader.nextInt();
		System.out.println("Est� en uso? [true] o [false]");
		reader.nextLine();
		boolean inUse = reader.nextBoolean();
		System.out.println("Ingrese la marca");
		reader.nextLine();
		String brand = reader.nextLine();
		secretary.addBillboard(w,h,inUse,brand);
	}
	public static void showBillboard() {
		System.out.println(secretary.showBillboardList());
	}
	public static void dangerousnessReport() {
		System.out.println(secretary.dangerousnessReport());
	}

}
